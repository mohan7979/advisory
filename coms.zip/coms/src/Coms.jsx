import React from "react"
export default function Coms() {
    return (
        <div style={{margin: '25%', textAlign: 'center', fontWeight: 'bold', fontSize: 30}} className="p-5 bg-blue-500 text-white -text-3xl font-bold">
           Coms  Micro Frontend
        </div>
    )
}