import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import Header from "./Header"
import Coms from "./Coms";

const App = () => (
  <div className="text-3xl mx-auto max-w-6xl">
    <Header />
    <div className="my-10">
      Home page Content
    </div>
    <Coms />
  </div>
);

ReactDOM.render(<App />, document.getElementById("app"));