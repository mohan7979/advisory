import React from "react"
export default function Header() {
    return (
        <div style={{ backgroundColor: "#333", margin: '-23px', height: '60px', display: 'flex', flexDirection: 'row'}}>
            <h1 style={{marginLeft: 30, color: "#fff"}}>ag</h1>
            <h2 style={{marginLeft:'35%', color: "#fff"}}> Advisory Gateway</h2>
        </div>
    )
}