import React, { useState } from "react";
import ReactDOM from "react-dom";
import "./index.css";
import Header from "home/Header";
import Dashboard from "./Dashboard";
const App = () => (
  
  <div className="text-3xl mx-auto max-w-6xl">
    <Header />
    <Dashboard />
  </div>
);
ReactDOM.render(<App />, document.getElementById("app"));