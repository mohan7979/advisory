import React, { useState } from "react";
import Coms from "home/Coms";
export default function Dashboard() {

    const [home, setHome] = useState(true);

    const handleClick = () => {
        setHome(!home);
    };

    return (
        <div style={{ display: "flex", flexDirection: 'row' }}>
            <div class="sidenav" style={{ flexDirection: 'column', margin: '23px 0px 0 -8px', width: '15%', height: '950px', backgroundColor: 'gray' }}>
                <a style={{ display: 'block', textDecoration: 'none', padding: '10px', backgroundColor: 'darkBlue', color: '#fff' }} href="#about">Household</a>
                <a style={{ display: 'block', textDecoration: 'none', padding: '10px', backgroundColor: 'darkBlue', color: '#fff' }} href="#services">Money Movement</a>
                <a style={{ display: 'block', textDecoration: 'none', padding: '10px', backgroundColor: 'darkBlue', color: '#fff' }} href="#clients">User Profile</a>
                <a style={{ display: 'block', textDecoration: 'none', padding: '10px', backgroundColor: 'darkBlue', color: '#fff' }} href="#contact">Settings</a>
            </div>
            {home && 
                <div class="text-center" style={{ flexDirection: 'column' }}>
                <div style={{ display: "flex", flexDirection: 'row', marginTop: 40 }}>
                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }} onClick={handleClick}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Arrow-Solution-Business-Computer-Technology-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>COMS</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Box-Arrow-Email-Mail-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>AOP</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Business-Report-Strategy-Present-Presentation-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>Money M</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Cd-Device-Sound-Music-Song-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>Finance</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Arrow-Solution-Business-Computer-Technology-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>COMS</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Box-Arrow-Email-Mail-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>AOP</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Business-Report-Strategy-Present-Presentation-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>Money M</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Cd-Device-Sound-Music-Song-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>Finance</div>
                    </div>
                </div>
                <div style={{ display: "flex", flexDirection: 'row', marginTop: 40 }}>
                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Arrow-Solution-Business-Computer-Technology-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>COMS</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Box-Arrow-Email-Mail-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>AOP</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Business-Report-Strategy-Present-Presentation-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>Money M</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Cd-Device-Sound-Music-Song-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>Finance</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Arrow-Solution-Business-Computer-Technology-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>COMS</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Box-Arrow-Email-Mail-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>AOP</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Business-Report-Strategy-Present-Presentation-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>Money M</div>
                    </div>

                    <div style={{ width: '100px', height: '100px', backgroundColor: '#2635B6', borderRadius: '25%', margin: 15 }}>
                        <img
                            src="https://icons.iconarchive.com/icons/justicon/free-simple-line/256/Cd-Device-Sound-Music-Song-icon.png"
                            class="rounded-full w-32 mb-4 mx-auto"
                            alt="Avatar"
                            height={70}
                            width={70}
                            style={{ margin: 15 }}
                        />
                        <div style={{ textAlign: 'center', fontWeight: 'bold' }}>Finance</div>
                    </div>
                </div>

            </div>
            }
            {!home &&
                <Coms />
            }
        </div>
    )
}